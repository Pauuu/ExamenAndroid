package com.example.pau.examen1pauvidal;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    SharedPreferences.Editor editor;

    Button countButton;
    Button toastButton;
    Button zeroButton;
    TextView textView;
    String value;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        countButton = (Button) findViewById(R.id.countButton);
        toastButton = (Button) findViewById(R.id.toastButton);
        zeroButton = (Button) findViewById(R.id.zeroButton);
        textView = (TextView) findViewById(R.id.textView);


        SharedPreferences prefs = getSharedPreferences("s", MODE_PRIVATE);
        String restoredText = prefs.getString("value", null);
        if (restoredText != null) {
            String sValue = prefs.getString("value", "No name defined");
            textView.setText(sValue);
        }


        Log.d("tag","si");

        countButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //pasa el charsequence to string, despres parsea a int i suma +1; al final ho converteix a string

                textView.setText(Integer.toString(Integer.parseInt(textView.getText().toString()) + 1));
            }
        });

        //mostra el toast
        toastButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), textView.getText() , Toast.LENGTH_SHORT).show();
            }
        });

        //reinicia contador a 0
        zeroButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                textView.setText("0");
            }
        });

    }

    @Override
    protected void onStop() {
        super.onStop();
        editor = getSharedPreferences("s", MODE_PRIVATE).edit();
        editor.putString("value", textView.getText().toString());
        editor.commit();

    }
}
